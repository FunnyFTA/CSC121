//Print "Hello World!" to output screen
#include <iostream>
using namespace std;

int main()
{
	cout << "\n\tHello World!" << endl;
	return 0;
}